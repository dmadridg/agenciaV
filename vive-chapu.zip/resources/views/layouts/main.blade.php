<!DOCTYPE html>
<html lang="en">
    <head>
        <title>@yield('title', isset($title) ? $title .' | Vive Chapultepec' : 'Vive Chapultepec')</title>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport" />
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <meta name="base-url" content="{{ url('') }}">
        <meta name="user-id" content="{{ auth()->user()->id }}">
        <meta name="description" content="Online payments" />
        <meta name="author" content="Conrado Carrillo" />

        <!-- Bootstrap Core CSS -->
        <link rel="stylesheet" href="{{ asset('plugins/bootstrap/css/bootstrap.min.css')}}"  type="text/css" media="screen"/>

        <!-- Font CSS -->
        <link rel="stylesheet" type="text/css" href="https://rawgit.com/noppa/text-security/master/dist/text-security.css">
        <link rel="stylesheet" href="{{ asset('dist/css/all_icons.css')}}"  type="text/css" media="screen"/>

        <!-- Loader CSS -->
        <link rel="stylesheet" href="{{ asset('dist/css/loader.css')}}"  type="text/css" media="screen"/>

        <!-- MetisMenu CSS -->
        <link rel="stylesheet" href="{{ asset('plugins/bootstrap-select2/select2.css') }}">
        <link rel="stylesheet" href="{{ asset('plugins/metisMenu/metisMenu.min.css')}}"  type="text/css" media="screen"/>
        <link rel="stylesheet" href="{{ asset('plugins/croppie/croppie.css')}}"  type="text/css" media="screen"/>
        <link rel="stylesheet" href="{{ asset('css/bootstrap-select.min.css')}}" type="text/css"/>
        {{-- <link rel="stylesheet" href="{{ asset('plugins/datepicker/datepicker3.css')}}" type="text/css"/> --}}
        <link href="{{asset('plugins/bootstrap-datepicker/css/datepicker.min.css')}}" rel="stylesheet" type="text/css" media="screen"/>
        <link rel="stylesheet" href="{{ asset('plugins/timepicker/bootstrap-timepicker.min.css')}}" type="text/css"/>
        <link rel="stylesheet" href="{{ asset('css/toastr.min.css')}}" type="text/css"/>
        <link rel="stylesheet" href="{{ asset('css/sweetalert.css') }}">
        <link rel="stylesheet" href="{{ asset('css/lightbox.css') }}">
        <link rel="stylesheet" href="{{ asset('/plugins/dropzone/css/dropzone.min.css') }}" type="text/css"/>


        <!-- Datatable CSS -->
        <link rel="stylesheet" href="{{ asset('plugins/jquery-datatable/css/jquery.dataTables.css')}}"  type="text/css" media="screen"/>

        <!-- Custom CSS -->
        <link rel="stylesheet" href="{{ asset('css/custom.css')}}"  type="text/css" media="screen"/>
        <link rel="stylesheet" href="{{ asset('dist/css/kavach.min.css')}}"  type="text/css" media="screen"/>
        <link rel="stylesheet" href="{{ asset('dist/css/animate.css')}}"  type="text/css" media="screen"/>


        <!-- Change Color CSS --> 
        <link rel="stylesheet" href="{{ asset('dist/css/skin/default-skin.css')}}"  type="text/css" media="screen"/>

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>
    <body>
        <div id="wrapper" class="">
            <div class="fakeLoader"></div>
            <!-- Navigation -->
            <nav class="navbar navbar-default navbar-static-top" style="margin-bottom: 0">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="{{url(auth()->user()->role->name == 'Administrador' ? 'dashboard' : 'mi-comercio')}}"><img src="{{asset('img/head-logo.png')}}" class="img-responsive" alt="Logo" /></a>
                </div>
                <!-- /.navbar-header -->
                
                <ul class="nav navbar-top-links navbar-left header-search-form hidden-xs">
                    <li><a class="menu-brand" id="menu-toggle"><span class="ti-view-grid"></span></a></li>
                </ul>
                <ul class="nav navbar-top-links navbar-right">
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <img src="{{asset(auth()->user()->photo)}}" class="img-responsive img-circle" alt="user" />
                        </a>
                        <ul class="dropdown-menu dropdown-user right-swip">
                            @if(auth()->user()->role->name == 'Cliente')
                                <li><a href="{{url('mi-comercio')}}"><i class="fa fa-user fa-fw"></i> Perfil</a></li>
                            @endif
                            {{-- <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a></li> --}}
                            <li class="change-password"><a href="javascript:;"><i class="fa fa-key fa-fw"></i> Cambiar contraseña</a></li>
                            <li class="log-out"><a href="javascript:;"><i class="fa fa-sign-out fa-fw"></i> Cerrar sesión</a></li>
                        </ul>
                        <!-- /.dropdown-user -->
                    </li>

                    <!-- /.dropdown -->
                </ul>
                <!-- /.navbar-top-links -->
                
                <!-- Sidebar Navigation -->
                <div class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu">

                            @if(auth()->user()->role->name == 'Administrador')
                                <li class="{{ ( in_array($menu,['Inicio']) ) ? 'active open' : '' }}">
                                    <a href="{{url('dashboard')}}"><i class="fa fa-bullseye"></i>Dashboard </a>
                                </li>
                                <li class="{{ ( in_array($menu,['Comercios']) ) ? 'active open' : '' }}">
                                    <a href="javascript:void(0)"><i class="fa fa-building"></i>Comercios <span class="fa arrow"></span></a>
                                    <ul class="nav nav-second-level">
                                        <li class="{{ ( in_array($menu,['Comercios']) && in_array($title, ['Lista de comercios'])) ? 'active open' : '' }}">
                                            <a href="{{url('comercios')}}">Listado de comercios</a>
                                        </li>
                                        <li class="{{ ( in_array($menu,['Comercios']) && in_array($title, ['Validar comercios'])) ? 'active open' : '' }}">
                                            <a href="{{url('comercios/validaciones')}}">Validar información de comercios</a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="{{ ( in_array($menu,['Clientes']) ) ? 'active open' : '' }}">
                                    <a href="{{url('clientes')}}"><i class="fa fa-users"></i>Clientes </a>
                                </li>
                                <li class="{{ ( in_array($menu,['Comentarios']) ) ? 'active open' : '' }}">
                                    <a href="{{url('comentarios')}}"><i class="fa fa-comments"></i>Aprobar comentarios </a>
                                </li>
                                <li class="{{ ( in_array($menu,['Faqs']) ) ? 'active open' : '' }}">
                                    <a href="{{url('faqs')}}"><i class="fa fa-question"></i>Preguntas frecuentes </a>
                                </li>
                                <li class="{{ ( in_array($menu,['Posts']) ) ? 'active open' : '' }}">
                                    <a href="{{url('posts')}}"><i class="fa fa-newspaper-o"></i>Posts </a>
                                </li>
                                <li class="{{ ( in_array($menu,['Eventos']) ) ? 'active open' : '' }}">
                                    <a href="{{url('eventos-y-actividades')}}"><i class="fa fa-calendar"></i>Eventos y actividades </a>
                                </li>
                                <li class="{{ ( in_array($menu,['Banners']) ) ? 'active open' : '' }}">
                                    <a href="{{url('espacios-fotos-app')}}"><i class="fa fa-image"></i>Banners </a>
                                </li>
                                <li class="{{ ( in_array($menu,['Cervezas']) ) ? 'active open' : '' }}">
                                    <a href="javascript:void(0)"><i class="fa fa-beer"></i>Cervezas <span class="fa arrow"></span></a>
                                    <ul class="nav nav-second-level">
                                        <li class="{{ ( in_array($menu,['Cervezas']) && in_array($title, ['Lista de cervezas'])) ? 'active open' : '' }}">
                                            <a href="{{url('cervezas')}}">Listado de cervezas</a>
                                        </li>
                                        <li class="{{ ( in_array($menu,['Cervezas']) && in_array($title, ['Estilos de cervezas'])) ? 'active open' : '' }}">
                                            <a href="{{url('cervezas/estilos')}}">Estilos de cerveza</a>
                                        </li>
                                    </ul>
                                </li>
                            @endif
                            
                            @if(auth()->user()->role->name == 'Comercio')
                                <li class="{{ ( in_array($menu,['Mi comercio']) ) ? 'active open' : '' }}">
                                    <a href="{{url('mi-comercio')}}"><i class="fa fa-user"></i>Perfil </a>
                                </li>
                                <li>
                                    <a href="{{url('cupones')}}"><i class="fa fa-tags"></i>Cupones </a>
                                </li>
                            @endif
                            <li>
                                <a href="javascript:;" class="log-out"><i class="fa fa-sign-out"></i>Cerrar sesión </a>
                            </li>
                        </ul>
                    </div>
                    <!-- /.sidebar-collapse -->
                </div>
            </nav>
            <!-- Sidebar Navigation -->

            <!-- jQuery -->
            <script src="{{ asset('plugins/jquery/dist/jquery.min.js') }}"></script>

            <!-- Conekta -->
            <script src="{{ asset('js/conekta_front.js') }}"></script>
            
            <!-- Pusher and custom js-->
            <script src="https://js.pusher.com/4.1/pusher.min.js"></script>
            <script src="{{ asset('js/systemFunctions.js') }}" type="text/javascript"></script>
            <script src="{{ asset('js/validFunctions.js') }}" type="text/javascript"></script>
            <script src="{{ asset('js/globalFunctions.js') }}" type="text/javascript"></script>
            <script src="{{ asset('js/generalAjax.js') }}" type="text/javascript"></script>
            
            <!-- ChartJS -->
            <script src="{{ asset('plugins/chart.js/Chart.bundle.js') }}"></script>
            <script src="{{ asset('plugins/chart.js/Chart.js') }}"></script>

            <div id="page-wrapper">
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h3 class="text-themecolor">@if(isset($title)) {{$title}} @else {{'Todo a meses'}} @endif </h3>
                    </div>
                </div>
                <main>
                    <section>
                        <div class="container-fluid">
                            @yield('content')
                        </div>  
                    </section>
                </main>
            </div>
            <!-- /#page-wrapper -->

            <!-- Bootstrap Core JavaScript -->
            <script src="{{ asset('plugins/bootstrap/js/bootstrap.min.js') }}"></script>

            <!-- Metis Menu Plugin JavaScript -->
            <script src="{{ asset('plugins/bootstrap-select2/select2.js') }}" type="text/javascript"></script>
            <script src="{{ asset('js/bootstrap-select.js')}}"></script>
            <script src="{{ asset('plugins/metisMenu/metisMenu.min.js') }}"></script>
            <script src="{{ asset('plugins/croppie/croppie.js') }}"></script>
            <script src="{{ asset('plugins/slim-scroll/js/jquery.slimscroll.js') }}"></script>
            <script src="{{ asset('dist/js/jQuery.style.switcher.js') }}"></script>
            <script src="{{ asset('dist/js/custom/form-wizard.js') }}"></script>
            
            <script src="{{asset('plugins/bootstrap-datepicker/js/bootstrap-datepicker.js')}}" type="text/javascript"></script>
            {{-- <script src="{{ asset('plugins/datepicker/bootstrap-datepicker.js') }}"></script> --}}
            <script src="{{ asset('plugins/timepicker/bootstrap-timepicker.min.js') }}"></script>
            <script src="{{ asset('js/toastr.min.js') }}"></script>
            <script src="{{ asset('js/lightbox.js') }}"></script>
            <script src="{{ asset('js/sweetalert.min.js') }}"></script>
            <script src="{{ asset('dist/js/jQuery.style.switcher.js') }}"></script>
            <script src="{{ asset('/plugins/dropzone/dropzone.js') }}" type="text/javascript"></script>


            <!-- Datatable scripts -->
            <script src="{{ asset('plugins/jquery-datatable/js/jquery.dataTables.js') }}" type="text/javascript"></script>
            <script src="{{ asset('plugins/jquery-datatable/extra/js/dataTables.tableTools.min.js') }}" type="text/javascript"></script>
            <script src="{{ asset('plugins/datatables-responsive/js/datatables.responsive.js') }}" type="text/javascript"></script>
            <script src="{{ asset('plugins/datatables-responsive/js/lodash.min.js') }}" type="text/javascript"></script>
            <script src="{{ asset('js/dataTables.js') }}"></script>

            <!-- FLOT CHARTS -->
            {{-- <script src="{{ asset('plugins/flot/jquery.flot.js') }}"></script> --}}
            <!-- FLOT RESIZE PLUGIN - allows the chart to redraw when the window is resized -->
            
            {{-- <script src="{{ asset('plugins/flot/jquery.flot.resize.js') }}"></script> --}}
            
            <!-- FLOT PIE PLUGIN - also used to draw donut charts -->
            {{-- <script src="{{ asset('plugins/flot/jquery.flot.pie.js') }}"></script> --}}
            
            <!-- FLOT CATEGORIES PLUGIN - Used to draw bar charts -->
            {{-- <script src="{{ asset('plugins/flot/jquery.flot.categories.js') }}"></script> --}}
            
            
            
            <!-- Loader JavaScript -->
            {{-- <script src="{{ asset('dist/js/loader.js') }}"></script> --}}

            <!-- Custom Theme JavaScript -->
            <script src="{{ asset('dist/js/kavach.min.js') }}"></script>
            
            <script type="text/javascript">
                var baseUrl = "{{url('')}}";
                var current_user_id = $('meta[name=user-id]').attr('content');
            </script>
            <!-- Custom Float JavaScript -->
            {{-- <script src="{{ asset('dist/js/custom/dashboard/dashboard1.js') }}"></script> --}}
            
            {{-- <footer class="footer"> © 2018 Todo a meses, desarrollado por Conrado Antonio </footer> --}}
        </div>
        <!-- /#wrapper -->
    </body>
</html>
