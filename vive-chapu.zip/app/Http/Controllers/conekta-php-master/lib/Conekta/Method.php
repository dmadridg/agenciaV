<?php 

namespace Conekta;

use \Conekta\Resource;

class Method extends Resource
{
}
